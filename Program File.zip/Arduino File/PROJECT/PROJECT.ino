/**
 * ════════════════════════════════════════════════════════════════
 *         YAW STABILITY CONTROL SYSTEM - Final Demo
 * ════════════════════════════════════════════════════════════════
 *
 * Demo Sequence:
 *   STEP 1 — OPEN LOOP    : No correction, robot drifts freely (15s)
 *   STEP 2 — PID HOLD     : Hold heading 0° for 20s (push to test)
 *   STEP 3 — FORWARD ROT  : Rotate +90°, +180°, +270°, +360° (PID)
 *   STEP 4 — BACKWARD ROT : Rotate -90°, -180°, -270°, -360° (PID)
 *   STEP 5 — MOVE FORWARD : Drive straight for 5s with PID yaw correction
 *
 * Hardware : ESP32, MPU6050 (I2C), 2× DC motors + L298N driver
 * Author   : Final Year Project — Yaw Stability Control
 * Date     : 2026-04-07
 * ════════════════════════════════════════════════════════════════
 */

#include <Wire.h>
#include <math.h>

// ================================================================
//  TUNABLE PARAMETERS  — adjust these for your robot
// ================================================================
#define PID_KP           2.0     // Proportional gain
#define PID_KI           0.1     // Integral gain
#define PID_KD           1.0     // Derivative gain

// Forward motion PID gains (usually needs lighter tuning than rotation)
#define FWD_KP           0.8     // Forward proportional gain (reduced for low speed stability)
#define FWD_KI           0.02    // Forward integral gain (reduced to prevent windup at low speed)
#define FWD_KD           0.3     // Forward derivative gain (reduced for smoother response)

#define MOTOR_MAX_SPEED  220     // Max PWM (0–255)
#define MOTOR_MIN_SPEED  100     // Min PWM to overcome stiction (give headroom for correction)
#define BASE_FWD_SPEED   130     // Base forward speed for straight drive (target speed ~130)
#define MAX_CORRECTION   30      // Max PID correction per side (forward) - allow reasonable correction range

#define ANGLE_TOLERANCE  0.5     // Rotation accuracy (degrees)
#define INTEGRAL_MAX     50.0    // PID integral anti-windup limit
#define IMU_TIMEOUT_MS   100     // Watchdog: stop if no IMU data (ms)

#define OPEN_LOOP_SECS   15      // Duration of open-loop demo
#define PID_HOLD_SECS    20      // Duration of PID heading-hold demo

// ================================================================
//  DEMO5 — ADAPTIVE PID GAIN BOUNDS  (forward straight-line drive)
// ================================================================
#define KP_MIN      0.4
#define KP_MAX      2.5
#define KD_MIN      0.05
#define KD_MAX      1.0
#define KI_MIN      0.0
#define KI_MAX      0.2

#define KP_ADAPT    0.02
#define KD_ADAPT    0.01
#define KI_ADAPT    0.001

// ================================================================
//  DEMO5 — AUTO GYRO CALIBRATION (idle-time drift correction)
// ================================================================
#define GYRO_IDLE_THRESHOLD  0.5    // °/s — below this is considered idle
#define IDLE_TIME_MS         2000   // ms of stillness before auto-calibrating
#define CALIB_ALPHA          0.01   // Low-pass blend factor for offset update

// ================================================================
//  PIN CONFIGURATION  — update to match your wiring
// ================================================================
#define E1  32   // Left  motor PWM  (LEDC)
#define I1  25   // Left  motor DIR1
#define I2  26   // Left  motor DIR2

#define E2  33   // Right motor PWM  (LEDC)
#define I3  27   // Right motor DIR1
#define I4  18   // Right motor DIR2

#define PWM_FREQ        5000
#define PWM_RESOLUTION  8        // 8-bit → 0–255

// ================================================================
//  MPU6050
// ================================================================
const int MPU = 0x68;

// ================================================================
//  GLOBALS
// ================================================================
float         angleZ        = 0;    // Integrated yaw (degrees)
float         gyroRate      = 0;    // Latest gyro-Z reading (°/s)
float         gyroOffset    = 0;    // Calibrated zero offset
unsigned long prevTime      = 0;
unsigned long lastIMUUpdate = 0;

// PID state
float pidIntegral  = 0;
float pidPrevError = 0;

// DEMO5 — Adaptive PID gains (used only in moveForwardPID)
float fwdKp = FWD_KP;
float fwdKi = FWD_KI;
float fwdKd = FWD_KD;

// DEMO5 — Auto gyro calibration state
unsigned long lastMotionTime = 0;
bool          isIdle         = false;

// ================================================================
//  HELPER — ASCII banner line
// ================================================================
void banner(const char* title) {
  Serial.println();
  Serial.println(F("╔════════════════════════════════════════════════════════════╗"));
  Serial.print  (F("║  "));
  Serial.print  (title);
  Serial.println(F("  ║"));
  Serial.println(F("╚════════════════════════════════════════════════════════════╝"));
}

// ================================================================
//  MPU6050 — CALIBRATE
// ================================================================
void calibrateGyro() {
  banner("GYRO CALIBRATION — Keep robot COMPLETELY STILL");
  long sum = 0;
  for (int i = 0; i < 1000; i++) {
    Wire.beginTransmission(MPU);
    Wire.write(0x47);
    Wire.endTransmission(false);
    Wire.requestFrom(MPU, 2, true);
    int16_t gz = Wire.read() << 8 | Wire.read();
    sum += gz;
    delay(2);
  }
  gyroOffset = (sum / 1000.0f) / 131.0f;
  Serial.print(F("  Gyro offset: "));
  Serial.print(gyroOffset, 4);
  Serial.println(F(" °/s  — Calibration complete!\n"));
}

// ================================================================
//  DEMO5 — ANGLE WRAP  (keeps error in -180° … +180° range)
// ================================================================
float angleError(float target, float current) {
  float err = target - current;
  while (err >  180) err -= 360;
  while (err < -180) err += 360;
  return err;
}

// ================================================================
//  DEMO5 — AUTO GYRO CALIBRATION
//  While the robot is stationary the gyro offset slowly tracks
//  residual drift without a full re-calibration stop.
// ================================================================
void updateGyroAutoCalibration(float gz_raw) {
  if (fabsf(gz_raw) > GYRO_IDLE_THRESHOLD) {
    lastMotionTime = millis();
    isIdle = false;
    return;
  }
  if (millis() - lastMotionTime > IDLE_TIME_MS) {
    isIdle = true;
  }
  if (isIdle) {
    gyroOffset = (1.0f - CALIB_ALPHA) * gyroOffset + CALIB_ALPHA * gz_raw;
  }
}

// ================================================================
//  MPU6050 — READ & INTEGRATE YAW
// ================================================================
void updateYaw() {
  Wire.beginTransmission(MPU);
  Wire.write(0x47);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU, 2, true);

  int16_t raw   = Wire.read() << 8 | Wire.read();
  float gz_raw  = raw / 131.0f;

  updateGyroAutoCalibration(gz_raw);       // DEMO5: continuous idle-drift correction

  float gz = gz_raw - gyroOffset;
  if (fabsf(gz) < 0.3f) gz = 0;           // DEMO5: tighter deadband (was 1.0°/s)

  unsigned long now = millis();
  float dt = (now - prevTime) / 1000.0f;
  prevTime = now;

  angleZ    += gz * dt;
  gyroRate   = gz;
  lastIMUUpdate = now;
}

// ================================================================
//  MOTOR PRIMITIVES
// ================================================================
void motorLeftFwd(int spd) {
  spd = constrain(spd, MOTOR_MIN_SPEED, MOTOR_MAX_SPEED);
  digitalWrite(I1, HIGH); digitalWrite(I2, LOW);
  ledcWrite(E1, spd);
}
void motorLeftBwd(int spd) {
  spd = constrain(spd, MOTOR_MIN_SPEED, MOTOR_MAX_SPEED);
  digitalWrite(I1, LOW);  digitalWrite(I2, HIGH);
  ledcWrite(E1, spd);
}
void motorLeftStop()  { ledcWrite(E1, 0); digitalWrite(I1, LOW);  digitalWrite(I2, LOW); }

void motorRightFwd(int spd) {
  spd = constrain(spd, MOTOR_MIN_SPEED, MOTOR_MAX_SPEED);
  digitalWrite(I3, HIGH); digitalWrite(I4, LOW);
  ledcWrite(E2, spd);
}
void motorRightBwd(int spd) {
  spd = constrain(spd, MOTOR_MIN_SPEED, MOTOR_MAX_SPEED);
  digitalWrite(I3, LOW);  digitalWrite(I4, HIGH);
  ledcWrite(E2, spd);
}
void motorRightStop() { ledcWrite(E2, 0); digitalWrite(I3, LOW);  digitalWrite(I4, LOW); }

void stopAll() { motorLeftStop(); motorRightStop(); }

// ================================================================
//  APPLY TORQUE — differential drive yaw correction (rotation only)
//  +torque = CCW (left spin), -torque = CW (right spin)
// ================================================================
void applyTorque(float torque) {
  torque = constrain(torque, -(float)MOTOR_MAX_SPEED, (float)MOTOR_MAX_SPEED);

  if (fabsf(torque) > 0 && fabsf(torque) < MOTOR_MIN_SPEED)
    torque = (torque > 0) ? MOTOR_MIN_SPEED : -MOTOR_MIN_SPEED;

  if (torque > 0) {
    motorLeftFwd ((int) torque);
    motorRightBwd((int) torque);
  } else if (torque < 0) {
    motorLeftBwd ((int)-torque);
    motorRightFwd((int)-torque);
  } else {
    stopAll();
  }
}

// ================================================================
//  PID COMPUTE
// ================================================================
void pidReset() { pidIntegral = 0; pidPrevError = 0; }

float pidCompute(float error, float dt) {
  float P = PID_KP * error;

  pidIntegral += error * dt;
  pidIntegral  = constrain(pidIntegral, -INTEGRAL_MAX, INTEGRAL_MAX);
  float I = PID_KI * pidIntegral;

  float D = PID_KD * (error - pidPrevError) / dt;
  pidPrevError = error;

  return P + I + D;
}

// Separate PID compute for forward motion (uses FWD gains)
float pidComputeFwd(float error, float dt) {
  float P = FWD_KP * error;

  pidIntegral += error * dt;
  pidIntegral  = constrain(pidIntegral, -INTEGRAL_MAX, INTEGRAL_MAX);
  float I = FWD_KI * pidIntegral;

  float D = FWD_KD * (error - pidPrevError) / dt;
  pidPrevError = error;

  return P + I + D;
}

// ================================================================
//  IMU WATCHDOG CHECK — call inside any control loop
// ================================================================
void checkIMU() {
  if (millis() - lastIMUUpdate > IMU_TIMEOUT_MS) {
    Serial.println(F("  ERROR: IMU timeout! Motors stopped."));
    stopAll();
    while (1);
  }
}

// ================================================================
//
//  DEMO 1 — OPEN LOOP (No Yaw Control)
//  Robot is pushed by hand; heading drifts with no correction.
//  Shows WHY yaw stability is needed.
//
// ================================================================
void demoOpenLoop() {
  banner("DEMO 1 — OPEN LOOP  (No Yaw Control)");
  Serial.println(F("  Motors are OFF. Robot cannot correct any drift."));
  Serial.println(F("  >>> PUSH OR TAP THE ROBOT to demonstrate drift <<<"));
  Serial.println(F("  Watching for 15 seconds...\n"));

  angleZ   = 0;
  prevTime = millis();
  delay(500);

  unsigned long start     = millis();
  unsigned long lastPrint = 0;
  float maxDrift = 0;

  while (millis() - start < (unsigned long)OPEN_LOOP_SECS * 1000) {
    updateYaw();                            // read only — NO correction

    float drift = fabsf(angleZ);
    if (drift > maxDrift) maxDrift = drift;

    if (millis() - lastPrint >= 500) {
      Serial.print(F("  [OPEN LOOP]  t="));
      Serial.print((millis() - start) / 1000.0f, 1);
      Serial.print(F("s  angle="));
      Serial.print(angleZ, 2);
      Serial.print(F("°  drift="));
      Serial.print(drift, 2);
      Serial.println(F("°"));
      lastPrint = millis();
    }
    delay(10);
  }

  stopAll();
  Serial.println();
  Serial.print(F("  Result — Max drift accumulated: "));
  Serial.print(maxDrift, 2);
  Serial.println(F("°"));
  Serial.println(F("  ↳ Without control the robot is completely unstable!\n"));
  delay(3000);
}

// ================================================================
//
//  DEMO 2 — PID CLOSED-LOOP HEADING HOLD  (20 seconds at 0°)
//  Robot actively fights any external disturbance to maintain 0°.
//
// ================================================================
void demoPIDHold() {
  banner("DEMO 2 — PID CLOSED-LOOP HEADING HOLD  (20s at 0 deg)");
  Serial.println(F("  PID actively corrects any drift to hold 0°."));
  Serial.println(F("  >>> PUSH THE ROBOT — watch it correct itself! <<<\n"));

  angleZ   = 0;
  prevTime = millis();
  pidReset();
  lastIMUUpdate = millis();

  const float target       = 0.0f;
  unsigned long start      = millis();
  unsigned long lastCtrl   = millis();
  unsigned long lastPrint  = 0;
  float maxError           = 0;

  while (millis() - start < (unsigned long)PID_HOLD_SECS * 1000) {
    unsigned long now = millis();
    float dt = (now - lastCtrl) / 1000.0f;
    lastCtrl = now;
    if (dt <= 0.0f) dt = 0.001f;

    updateYaw();
    float err    = target - angleZ;
    float output = pidCompute(err, dt);
    applyTorque(output);
    checkIMU();

    float absErr = fabsf(err);
    if (absErr > maxError) maxError = absErr;

    if (millis() - lastPrint >= 500) {
      Serial.print(F("  [PID HOLD]  t="));
      Serial.print((millis() - start) / 1000.0f, 1);
      Serial.print(F("s  angle="));
      Serial.print(angleZ, 2);
      Serial.print(F("°  error="));
      Serial.print(absErr, 2);
      Serial.print(F("°  gyro="));
      Serial.print(gyroRate, 1);
      Serial.println(F("°/s"));
      lastPrint = millis();
    }

    delay(1);
  }

  stopAll();
  Serial.println();
  Serial.print(F("  Result — Max error during hold: "));
  Serial.print(maxError, 2);
  Serial.println(F("°"));
  Serial.println(F("  ↳ PID maintained heading despite disturbances!\n"));
  delay(3000);
}

// ================================================================
//
//  DEMO 3 — FORWARD (POSITIVE) ROTATION  +90° → +180° → +270° → +360°
//  PID closed-loop rotates to each target with ±0.5° accuracy.
//
// ================================================================
void demoForwardRotation() {
  banner("DEMO 3 — FORWARD ROTATION  (+90 / +180 / +270 / +360)");
  Serial.println(F("  PID drives each positive-angle target in sequence."));
  Serial.println(F("  Accuracy target: ±0.5°\n"));

  angleZ   = 0;
  prevTime = millis();
  delay(300);

  float targets[] = { 90.0, 180.0, 270.0, 360.0 };

  for (int i = 0; i < 4; i++) {
    float target = targets[i];
    pidReset();
    lastIMUUpdate = millis();

    Serial.print(F("  → Rotating to +"));
    Serial.print(target, 0);
    Serial.println(F("°"));

    unsigned long lastCtrl = millis();

    while (fabsf(angleZ - target) > ANGLE_TOLERANCE) {
      unsigned long now = millis();
      float dt = (now - lastCtrl) / 1000.0f;
      lastCtrl = now;
      if (dt <= 0.0f) dt = 0.001f;

      updateYaw();
      float err    = target - angleZ;
      float output = pidCompute(err, dt);
      applyTorque(output);
      checkIMU();
    }

    stopAll();
    float finalErr = fabsf(angleZ - target);
    Serial.print(F("    Reached "));
    Serial.print(angleZ, 2);
    Serial.print(F("°  |  error = "));
    Serial.print(finalErr, 2);
    Serial.println(F("°"));
    delay(1500);
  }

  Serial.println(F("\n  ✓ All forward rotations complete with ±0.5° accuracy\n"));
  delay(3000);
}

// ================================================================
//
//  DEMO 4 — BACKWARD (NEGATIVE) ROTATION  -90° → -180° → -270° → -360°
//  Same PID, opposite direction — proves bidirectional accuracy.
//
// ================================================================
void demoBackwardRotation() {
  banner("DEMO 4 — BACKWARD ROTATION  (-90 / -180 / -270 / -360)");
  Serial.println(F("  PID drives each negative-angle target in sequence."));
  Serial.println(F("  Accuracy target: ±0.5°\n"));

  angleZ   = 0;
  prevTime = millis();
  delay(300);

  float targets[] = { -90.0, -180.0, -270.0, -360.0 };

  for (int i = 0; i < 4; i++) {
    float target = targets[i];
    pidReset();
    lastIMUUpdate = millis();

    Serial.print(F("  → Rotating to "));
    Serial.print(target, 0);
    Serial.println(F("°"));

    unsigned long lastCtrl = millis();

    while (fabsf(angleZ - target) > ANGLE_TOLERANCE) {
      unsigned long now = millis();
      float dt = (now - lastCtrl) / 1000.0f;
      lastCtrl = now;
      if (dt <= 0.0f) dt = 0.001f;

      updateYaw();
      float err    = target - angleZ;
      float output = pidCompute(err, dt);
      applyTorque(output);
      checkIMU();
    }

    stopAll();
    float finalErr = fabsf(angleZ - target);
    Serial.print(F("    Reached "));
    Serial.print(angleZ, 2);
    Serial.print(F("°  |  error = "));
    Serial.print(finalErr, 2);
    Serial.println(F("°"));
    delay(1500);
  }

  Serial.println(F("\n  ✓ All backward rotations complete with ±0.5° accuracy\n"));
  delay(3000);
}

// ================================================================
//
//  DEMO 5 — MOVE FORWARD WITH ADAPTIVE PID YAW CORRECTION
//
//  Integrated improvements from DEMO5:
//    • angleError()  — wraps heading error to -180…+180° range
//    • Dead zone     — errors < 0.7° ignored to prevent motor chatter
//    • Adaptive PID  — Kp, Ki, Kd self-tune each iteration:
//        Kp rises when error > 5°, falls when error < 1°
//        Kd rises on sign-flip (oscillation detected), else falls
//        Ki rises near target (absErr < 1°), else decays
//    • Auto gyro calibration — updateGyroAutoCalibration() runs
//      inside updateYaw() throughout the drive
//
//  Correction direction (same as original):
//    Left  motor = BASE - correction
//    Right motor = BASE + correction
//
// ================================================================
void moveForwardPID(float durationSeconds) {
  banner("DEMO 5 — MOVE FORWARD  (PID Straight-Line Control)");
  Serial.print  (F("  Driving straight for "));
  Serial.print  (durationSeconds, 1);
  Serial.println(F(" seconds with yaw correction.\n"));

  updateYaw();
  float targetHeading = angleZ;

  // Reset adaptive gain state to starting values
  fwdKp = FWD_KP;
  fwdKi = FWD_KI;
  fwdKd = FWD_KD;
  pidReset();

  prevTime      = millis();
  lastIMUUpdate = millis();

  unsigned long start     = millis();
  unsigned long lastCtrl  = millis();
  unsigned long lastPrint = millis();

  float maxHeadingErr = 0;

  while (millis() - start < (unsigned long)(durationSeconds * 1000UL)) {

    unsigned long now = millis();
    float dt = (now - lastCtrl) / 1000.0f;
    lastCtrl = now;
    if (dt <= 0.0f) dt = 0.001f;

    updateYaw();
    checkIMU();

    // DEMO5: wrapped angle error stays in -180…+180°
    float error = angleError(targetHeading, angleZ);

    // DEMO5: dead zone — ignore tiny errors to prevent chatter
    if (fabsf(error) < 0.7f) error = 0;

    // ── DEMO5: Adaptive PID ──────────────────────────────────────
    float absErr = fabsf(error);

    // Adapt Kp
    if (absErr > 5.0f) fwdKp += KP_ADAPT;
    else if (absErr < 1.0f) fwdKp -= KP_ADAPT;
    fwdKp = constrain(fwdKp, KP_MIN, KP_MAX);

    // Adapt Kd (detect oscillation by sign flip)
    if ((error > 0 && pidPrevError < 0) || (error < 0 && pidPrevError > 0))
      fwdKd += KD_ADAPT;
    else
      fwdKd -= KD_ADAPT;
    fwdKd = constrain(fwdKd, KD_MIN, KD_MAX);

    // Integral — only accumulate near target, decay when far
    if (absErr < 2.0f)
      pidIntegral += error * dt;
    else
      pidIntegral *= 0.9f;
    pidIntegral = constrain(pidIntegral, -INTEGRAL_MAX, INTEGRAL_MAX);

    // Adapt Ki
    fwdKi += KI_ADAPT * (absErr < 1.0f ? 1.0f : -1.0f);
    fwdKi = constrain(fwdKi, KI_MIN, KI_MAX);

    // Compute output
    float P = fwdKp * error;
    float I = fwdKi * pidIntegral;
    float D = fwdKd * (error - pidPrevError) / dt;
    pidPrevError = error;

    float correction = constrain(P + I + D, -(float)MAX_CORRECTION, (float)MAX_CORRECTION);
    // ─────────────────────────────────────────────────────────────

    int leftSpeed  = BASE_FWD_SPEED - (int)correction;
    int rightSpeed = BASE_FWD_SPEED + (int)correction;

    leftSpeed  = constrain(leftSpeed,  MOTOR_MIN_SPEED, MOTOR_MAX_SPEED);
    rightSpeed = constrain(rightSpeed, MOTOR_MIN_SPEED, MOTOR_MAX_SPEED);

    motorLeftBwd (leftSpeed);
    motorRightBwd(rightSpeed);

    if (absErr > maxHeadingErr) maxHeadingErr = absErr;

    if (millis() - lastPrint >= 300) {
      Serial.print(F("  [FWD PID]  t="));
      Serial.print((millis() - start) / 1000.0f, 1);
      Serial.print(F("s  heading="));
      Serial.print(angleZ, 2);
      Serial.print(F("°  err="));
      Serial.print(error, 2);
      Serial.print(F("°  corr="));
      Serial.print(correction, 1);
      Serial.print(F("  Kp="));
      Serial.print(fwdKp, 3);
      Serial.print(F("  Kd="));
      Serial.print(fwdKd, 3);
      Serial.print(F("  L="));
      Serial.print(leftSpeed);
      Serial.print(F("  R="));
      Serial.println(rightSpeed);
      lastPrint = millis();
    }

    delay(5);
  }

  stopAll();
  Serial.println();
  Serial.print(F("  Result — Max heading error during run: "));
  Serial.print(maxHeadingErr, 2);
  Serial.println(F("°"));
  Serial.println(F("  ↳ Robot drove straight with active yaw correction!\n"));
  delay(3000);
}

// ================================================================
//  SETUP
// ================================================================
void setup() {
  Serial.begin(115200);
  Wire.begin();

  // Motor pins
  pinMode(I1, OUTPUT); pinMode(I2, OUTPUT);
  pinMode(I3, OUTPUT); pinMode(I4, OUTPUT);

  // PWM channels (ESP32 LEDC)
  ledcAttach(E1, PWM_FREQ, PWM_RESOLUTION);
  ledcAttach(E2, PWM_FREQ, PWM_RESOLUTION);
  stopAll();

  // MPU6050 wake-up
  Wire.beginTransmission(MPU);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.endTransmission(true);
  delay(1000);

  // Calibrate gyro
  calibrateGyro();
  prevTime      = millis();
  lastIMUUpdate = prevTime;

  // Startup banner
  Serial.println(F("════════════════════════════════════════════════════════════"));
  Serial.println(F("       YAW STABILITY CONTROL SYSTEM  —  Ready"));
  Serial.println(F("════════════════════════════════════════════════════════════"));
  Serial.println(F("  Demo sequence:"));
  Serial.println(F("    1. Open Loop        — No control, robot drifts freely"));
  Serial.println(F("    2. PID Heading Hold — 20s at 0°, push to test"));
  Serial.println(F("    3. Forward Rotation — +90 / +180 / +270 / +360 (PID)"));
  Serial.println(F("    4. Backward Rotation— -90 / -180 / -270 / -360 (PID)"));
  Serial.println(F("    5. Move Forward PID — Drive straight 5s"));
  Serial.println(F("────────────────────────────────────────────────────────────"));
  Serial.print  (F("  Rotation PID — Kp: ")); Serial.print(PID_KP);
  Serial.print  (F("  Ki: "));                Serial.print(PID_KI);
  Serial.print  (F("  Kd: "));                Serial.println(PID_KD);
  Serial.print  (F("  Forward  PID — Kp: ")); Serial.print(FWD_KP);
  Serial.print  (F("  Ki: "));                Serial.print(FWD_KI);
  Serial.print  (F("  Kd: "));                Serial.println(FWD_KD);
  Serial.println(F("  Forward PID mode: Adaptive (Kp/Ki/Kd self-tune per loop)"));
  Serial.println(F("  Gyro calibration: Initial + continuous idle auto-correction"));
  Serial.print  (F("  Base forward speed  : ")); Serial.println(BASE_FWD_SPEED);
  Serial.println(F("════════════════════════════════════════════════════════════\n"));
  Serial.println(F("  Starting in 3 seconds..."));
  delay(3000);
}

// ================================================================
//  MAIN LOOP
// ================================================================
void loop() {
  Serial.println(F("\n\n════════════════════════════════════════════════════════════"));
  Serial.println(F("               DEMO SEQUENCE STARTING"));
  Serial.println(F("════════════════════════════════════════════════════════════"));

  // ── Step 1: Open Loop ──────────────────────────────────────────
  demoOpenLoop();
  delay(4000);

  // ── Step 2: PID Closed-Loop Hold ──────────────────────────────
  demoPIDHold();
  delay(4000);

  // ── Step 3: Forward Rotations ─────────────────────────────────
  demoForwardRotation();
  delay(4000);

  // ── Step 4: Backward Rotations ────────────────────────────────
  demoBackwardRotation();
  delay(4000);

  // ── Step 5: Move Forward with PID ─────────────────────────────
  moveForwardPID(5.0);   // Drive straight for 5 seconds
  delay(4000);

  // ── Complete ──────────────────────────────────────────────────
  stopAll();
  Serial.println(F("════════════════════════════════════════════════════════════"));
  Serial.println(F("                    DEMO COMPLETE"));
  Serial.println(F("════════════════════════════════════════════════════════════"));
  Serial.println(F("  ✓ Open Loop      — drifted uncontrollably (unstable)"));
  Serial.println(F("  ✓ PID Hold       — maintained heading vs disturbances"));
  Serial.println(F("  ✓ Forward Rot    — ±0.5° accuracy on +90/180/270/360"));
  Serial.println(F("  ✓ Backward Rot   — ±0.5° accuracy on -90/180/270/360"));
  Serial.println(F("  ✓ Move Forward   — drove straight with PID yaw correction"));
  Serial.println(F("────────────────────────────────────────────────────────────"));
  Serial.println(F("  Key message for judges:"));
  Serial.println(F("    Open loop  → heading drifts  (no correction)"));
  Serial.println(F("    Closed PID → heading held    (active correction)"));
  Serial.println(F("════════════════════════════════════════════════════════════"));
  Serial.println(F("  Power cycle to run again."));

  while (1);   // halt
}